<?php

namespace seraph_accel\JSMin;

class UnterminatedCommentException extends \Exception {
}
